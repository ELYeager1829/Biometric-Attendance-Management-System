namespace BiometricClocking.API.Models;

public enum UserRole
{
    Employee,
    Admin
}