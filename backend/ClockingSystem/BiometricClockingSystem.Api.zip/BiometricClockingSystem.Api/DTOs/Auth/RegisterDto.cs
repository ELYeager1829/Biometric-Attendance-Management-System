using BiometricClocking.API.Models;

namespace BiometricClockingSystem.Api.DTOs;

public class RegisterDto
{
    public string EmployeeNumber { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;

    public string Password { get; set; } = string.Empty;

    public UserRole Role { get; set; }
}