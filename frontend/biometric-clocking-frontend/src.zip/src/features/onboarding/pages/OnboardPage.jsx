import { useEffect, useRef, useState } from 'react'
import { useLocation } from 'react-router-dom'
import Panel from '../../../shared/components/Panel'

const Field = ({ name, label, placeholder, select, defaultValue }) => (
  <label className="block text-[10px] font-bold tracking-widest text-slate-400">
    {label}
    {select ? (
      <select name={name} defaultValue={defaultValue || 'Select department'} className="mt-2 w-full rounded-lg bg-[#09192c] p-3 text-sm text-slate-300">
        <option>Select department</option>
        <option>Engineering</option>
        <option>Product</option>
        <option>Operations</option>
        <option>Finance</option>
        <option>People</option>
      </select>
    ) : (
      <input name={name} defaultValue={defaultValue} className="mt-2 w-full rounded-lg bg-[#09192c] p-3 text-sm outline-none focus:border-sky-500" placeholder={placeholder} />
    )}
  </label>
)

function getFrameQuality(canvas) {
  const context = canvas.getContext('2d')
  const { data, width, height } = context.getImageData(0, 0, canvas.width, canvas.height)
  let brightness = 0
  let edgeDiff = 0
  let samples = 0

  for (let y = 0; y < height; y += 12) {
    for (let x = 0; x < width; x += 12) {
      const index = (y * width + x) * 4
      const nextIndex = (y * width + Math.min(x + 12, width - 1)) * 4
      const luminance = data[index] * 0.299 + data[index + 1] * 0.587 + data[index + 2] * 0.114
      const nextLuminance = data[nextIndex] * 0.299 + data[nextIndex + 1] * 0.587 + data[nextIndex + 2] * 0.114
      brightness += luminance
      edgeDiff += Math.abs(luminance - nextLuminance)
      samples += 1
    }
  }

  const averageBrightness = brightness / samples
  const averageEdgeDiff = edgeDiff / samples

  if (averageBrightness < 45) return { clear: false, message: 'Picture is not clear. Add more light and face the camera.' }
  if (averageBrightness > 235) return { clear: false, message: 'Picture is too bright. Reduce glare and face the camera.' }
  if (averageEdgeDiff < 3.5) return { clear: false, message: 'Picture is not clear. Hold still and face the camera.' }

  return { clear: true, message: '' }
}

function canvasToJpegBlob(canvas, quality = 0.86) {
  return new Promise(resolve => {
    canvas.toBlob(blob => resolve(blob), 'image/jpeg', quality)
  })
}

export default function OnboardPage({ onBack }) {
   const location = useLocation();

  const mode = location.state?.mode || "create";
  const employee = location.state?.employee || null;
  
  const formRef = useRef(null)
  const videoRef = useRef(null)
  const canvasRef = useRef(null)
  const [capturedPhoto, setCapturedPhoto] = useState('');
  const [capturedPhotoBlob, setCapturedPhotoBlob] = useState(null);
  const [cameraError, setCameraError] = useState('');
  const [cameraRetryKey, setCameraRetryKey] = useState(0);
  const [saving, setSaving] = useState(false);
  const captured = Boolean(capturedPhoto);
  const isEdit = mode === 'edit'
  const [firstName, ...lastNameParts] = employee?.name?.split(' ') || []
  const lastName = lastNameParts.join(' ')

  useEffect(() => {
    let stream

    const startCamera = async () => {
      try {
        setCameraError('')
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false })
        if (!videoRef.current) return

        videoRef.current.srcObject = stream
        videoRef.current.onloadedmetadata = () => videoRef.current.play()
      } catch {
        setCameraError('Camera access is required to capture a facial image.')
      }
    }

    startCamera()

    return () => {
      stream?.getTracks().forEach(track => track.stop())
    }
  }, [cameraRetryKey])

  const capturePhoto = async () => {
    if (capturedPhoto) {
      setCapturedPhoto('')
      setCapturedPhotoBlob(null)
      return
    }

    const video = videoRef.current
    const canvas = canvasRef.current
    if (!video || !canvas) return

    canvas.width = video.videoWidth || 640
    canvas.height = video.videoHeight || 480
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height)
    const quality = getFrameQuality(canvas)

    if (!quality.clear) {
      setCameraError(quality.message)
      return
    }

    setCameraError('')
    setCapturedPhotoBlob(await canvasToJpegBlob(canvas))
    setCapturedPhoto(canvas.toDataURL('image/jpeg', 0.86))
  }

  const saveEmployee = async () => {
    const formData = new FormData(formRef.current)

    const employeeNumber = formData.get('employeeNumber')
    const firstName = formData.get('firstName')
    const lastName = formData.get('lastName')
    const department = formData.get('department')
    const position = formData.get('position')
    const phoneNumber = formData.get('phoneNumber')

    if (!employeeNumber || !firstName || !lastName || !department || !position || !phoneNumber) {
      alert('Please complete all employee details.')
      return
    }

    if (!capturedPhoto) {
      alert('Please capture the employee facial image.')
      return
    }
    setSaving(true)

    try {
      const token = localStorage.getItem('token')

      const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5160/api'

      const url = isEdit
        ? `${API_URL}/Employee/${employee.employeeNumber}`
        : `${API_URL}/Employee`

      const response = await fetch(url, {
        method: isEdit ? 'PUT' : 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          employeeNumber,
          firstName,
          lastName,
          department,
          position,
          phoneNumber,
          faceImageBase64: capturedPhoto
        })
      })

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(errorText || 'Failed to save employee.')
      }

      const result = await response.json()

      console.log('Employee saved successfully:', result)

      alert(
        isEdit
          ? 'Employee updated successfully!'
          : 'Employee registered successfully!'
      )

      onBack()

    } catch (error) {
      console.error('Employee save error:', error)

      alert(
        error.message || 'Something went wrong while saving the employee.'
      )

    } finally {
      setSaving(false)
    }
  }

  return (
    <main className="min-h-screen bg-[#071525] text-slate-200">
      <header className="flex h-18 items-center justify-between bg-[#0a1a2e] px-[5vw] py-4">
        <button onClick={onBack} className="text-xs font-bold text-sky-300">← Back to directory</button>
        <b className="text-sm tracking-widest text-white">VERITY</b>
      </header>

      <section className="mx-auto max-w-5xl px-5 py-10">
        <h1 className="mt-2 text-3xl font-bold tracking-tight text-white">{isEdit ? 'Edit employee details' : 'Onboard new employee'}</h1>

        <div className="mt-7 grid gap-5 lg:grid-cols-[1.25fr_.75fr]">
          <Panel className="p-6">
            <h2 className="font-bold text-white">Personal details</h2>
            <form ref={formRef} className="mt-6 grid gap-x-4 gap-y-5 sm:grid-cols-2">
              <Field name="firstName" label="FIRST NAME" placeholder="e.g. Samira" defaultValue={firstName} />
              <Field name="lastName" label="LAST NAME" placeholder="e.g. Patel" defaultValue={lastName} />
              <Field name="employeeNumber" label="EMPLOYEE ID" placeholder="e.g. EMP001" defaultValue={employee?.employeeNumber} />
              <Field name="email" label="WORK EMAIL" placeholder="samira@company.com" />
              <Field
                name="phoneNumber"
                label="PHONE NUMBER"
                placeholder="0821234567"
              />
              <Field name="department" label="DEPARTMENT" select defaultValue={employee?.dept} />
              <Field name="position" label="ROLE" placeholder="e.g. Product Designer" />
            </form>
          </Panel>

          <Panel className="flex flex-col p-6">
            <h2 className="font-bold text-white">Biometric enrollment</h2>

            <div className={`relative mt-6 flex min-h-44 flex-col items-center justify-center overflow-hidden rounded-xl border border-dashed ${captured ? 'border-emerald-400 bg-emerald-500/5 text-emerald-300' : 'border-slate-600 bg-[#09192c] text-sky-300'}`}>
              <video ref={videoRef} onPause={() => videoRef.current?.play().catch(() => null)} className="h-44 w-full object-cover" muted playsInline autoPlay />
              {capturedPhoto && (
                <img src={capturedPhoto} alt="Captured employee" className="absolute inset-0 h-44 w-full object-cover" />
              )}
              <canvas ref={canvasRef} className="hidden" />
              <div className="absolute inset-x-0 bottom-0 bg-[#071525cc] p-3 text-center">
                <b className="text-sm text-slate-100">{captured ? 'Face captured' : 'Camera ready'}</b>
                <span className="mt-1 block text-[10px] text-slate-400">{cameraError || (captured ? 'Baseline identity image saved' : 'Ensure even lighting and clear face visibility')}</span>
              </div>
              {cameraError && (
                <button onClick={() => setCameraRetryKey(value => value + 1)} className="absolute left-1/2 top-4 -translate-x-1/2 rounded-lg bg-sky-600 px-3 py-2 text-xs font-bold text-white">
                  Retry camera
                </button>
              )}
            </div>
            <button onClick={capturePhoto} className="mt-4 w-full rounded-lg  bg-[#10233a] py-3 text-xs font-bold hover:bg-slate-500">
              {captured ? 'Re-capture photo' : 'Capture facial image'}
            </button>
            <p className="mt-5 text-[10px] leading-4 text-slate-400">
              Biometric data is encrypted before storage and used only for attendance verification.
            </p>
          </Panel>
        </div>

        <footer className="mt-6 flex justify-end gap-3">
          <button onClick={onBack} className="rounded-lg px-5 py-3 text-xs font-bold  hover:bg-slate-500">Cancel</button>
          <button onClick={saveEmployee} disabled={saving} className="rounded-lg bg-sky-600 px-5 py-3 text-xs font-bold text-white hover:bg-slate-700 disabled:opacity-40">{saving ? 'Saving...' : (isEdit ? 'Save changes' : 'Register employee')}</button>
        </footer>
      </section>
    </main>
  )
}
