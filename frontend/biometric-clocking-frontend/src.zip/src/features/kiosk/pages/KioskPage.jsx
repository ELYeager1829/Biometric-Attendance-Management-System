import { useEffect, useRef, useState } from 'react'
import { Check } from 'lucide-react'
import Modal from '../../../shared/components/Modal'
import { LOGIN_EMAILS } from '../../../config/auth'
import backGr from '../../../assests/main-background.jpeg'

function AdminLogin({ onClose, onLogin }) {
  const [email, setEmail] = useState('')
  const loginRole = () => {
    onLogin(email.trim().toLowerCase() === LOGIN_EMAILS.hr ? 'hr' : 'admin')
  }

  return (
    <Modal onClose={onClose}>
      <h2 className="text-xl font-bold text-white">Admin access</h2>
      <p className="mt-2 text-sm leading-6 text-slate-400">Sign in to manage employee records and attendance.</p>
      <label className="mt-6 block text-[10px] font-bold">EMAIL OR USERNAME</label>
      <input value={email} onChange={event => setEmail(event.target.value)} className="mt-2 w-full rounded-lg bg-[#09192c] px-3 py-3 text-sm outline-none" placeholder="admin@verity.co"/>
      <label className="mt-4 block text-[10px] font-bold">PASSWORD</label>
      <input type="password" className="mt-2 w-full rounded-lg bg-[#09192c] px-3 py-3 text-sm outline-none focus:border-sky-500" placeholder="••••••••"/>
      <button onClick={loginRole} className="mt-5 w-full rounded-lg bg-sky-600 py-3 text-sm font-bold text-white hover:bg-sky-500">Log in</button>
      <button onClick={loginRole} className="mt-3 w-full rounded-lg bg-[#0b1b30] py-3 text-sm font-semibold text-slate-200 hover:bg-[#2b2f36]">Log in with fingerprint</button>
    </Modal>
  )
}

function CallAdmin({ onClose, onNotify }) {
  const [employeeNumber, setEmployeeNumber] = useState('')

  return (
    <Modal onClose={onClose}>
      <h2 className="text-xl font-bold text-white">Admin notified... Please wait</h2>
      <label className="mt-6 block text-[10px] font-bold">EMPLOYEE NUMBER</label>
      <input value={employeeNumber} onChange={e => setEmployeeNumber(e.target.value)} className="mt-2 w-full rounded-lg bg-[#09192c] px-3 py-3 text-sm outline-none" placeholder="EMP-1042"/>
      <div className="my-6 rounded-lg bg-[#09192c] p-4 text-sky-300">
        <b className="text-sm text-white">status must change from clocked in or out whithe user waits</b>
      </div>
      <button disabled={!employeeNumber.trim()} onClick={() => onNotify(employeeNumber.trim())} className="w-full rounded-lg bg-sky-600 py-3 text-sm font-bold text-white disabled:opacity-40">Notify admin</button>
    </Modal>
  )
}

function NoticeModal({ message, onClose }) {
  return (
    <Modal onClose={onClose}>
      <h2 className="text-xl font-bold text-white">{message}</h2>
      <button onClick={onClose} className="mt-6 w-full rounded-lg bg-sky-600 py-3 text-sm font-bold text-white">Understood</button>
    </Modal>
  )
}

function getFrameQuality(canvas) {
  const context = canvas.getContext('2d')
  const { data, width, height } = context.getImageData(0, 0, canvas.width, canvas.height)
  let brightness = 0
  let edgeDiff = 0
  let samples = 0

  for (let y = 0; y < height; y += 12) {
    for (let x = 0; x < width; x += 12) {
      const index = (y * width + x) * 4
      const nextIndex = (y * width + Math.min(x + 12, width - 1)) * 4
      const luminance = data[index] * 0.299 + data[index + 1] * 0.587 + data[index + 2] * 0.114
      const nextLuminance = data[nextIndex] * 0.299 + data[nextIndex + 1] * 0.587 + data[nextIndex + 2] * 0.114
      brightness += luminance
      edgeDiff += Math.abs(luminance - nextLuminance)
      samples += 1
    }
  }

  const averageBrightness = brightness / samples
  const averageEdgeDiff = edgeDiff / samples

  if (averageBrightness < 45) return { clear: false, message: 'Picture is not clear. Add more light and face the camera.' }
  if (averageBrightness > 235) return { clear: false, message: 'Picture is too bright. Reduce glare and face the camera.' }
  if (averageEdgeDiff < 3.5) return { clear: false, message: 'Picture is not clear. Hold still and face the camera.' }

  return { clear: true, message: 'Face detected. Verifying...' }
}

function canvasToJpegBlob(canvas, quality = 0.82) {
  return new Promise(resolve => {
    canvas.toBlob(blob => resolve(blob), 'image/jpeg', quality)
  })
}

function Success() {
  const [count, setCount] = useState(3);
  useEffect(() => {
    const countdown = setInterval(() => {
      setCount(value => Math.max(value - 1, 0))
    }, 1000)

    return () => clearInterval(countdown)
  }, []);

  return (
    <main className="min-h-screen bg-[#071525] px-5 pt-[14vh] text-center">
      <div className="mx-auto grid h-28 w-28 place-items-center rounded-full border-[10px] border-emerald-400/10 bg-emerald-500 text-white shadow-xl shadow-emerald-950/50">
        <Check size={65} strokeWidth={3}/>
      </div>
      <p className="mt-8 text-xs font-semibold text-emerald-300">IDENTITY VERIFIED</p>
      <h1 className="mt-3 text-4xl font-bold tracking-tight text-white">Successfully Clocked In</h1>
      <div className="mx-auto mt-7 flex w-full max-w-sm items-center gap-3 rounded-xl bg-[#eef4fc] p-4">
        <div className="flex-1 text-left">
          <b className="block text-xl text-[#071525]">Amara Mensah</b>
          <span className="text-sm text-[#071525]">EMP-1042</span>
        </div>
        <time className="pl-3 leading-5 text-sm text-[#071525]">
          2026-07-28<br/>
          <b className="text-sm">09:47:15</b>
        </time>
      </div>
      <p className="mt-5 text-xs text-white">Returning to kiosk in {count} seconds</p>
    </main>
  )
}

export default function KioskPage({ onAdminAccess, onAdminCall }) {
  const videoRef = useRef(null)
  const canvasRef = useRef(null)
  const faceCheckStartedRef = useRef(false)
  const [now, setNow] = useState(new Date());
  const [otp, setOtp] = useState('');
  const [modal, setModal] = useState(null);
  const [verifying, setVerifying] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const [cameraRetryKey, setCameraRetryKey] = useState(0);
  const [faceStatus, setFaceStatus] = useState('Looking for face...');
  const [success, setSuccess] = useState(false)

  const resetToKiosk = () => {
    setSuccess(false);
    setOtp('');
    setVerifying(false);
    setModal(null);
    faceCheckStartedRef.current = false;
    setCameraRetryKey(value => value + 1)
  }

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t)
  }, []);

  useEffect(() => {
    if (success) return

    let stream
    let stopped = false

    const captureFrame = async () => {
      const video = videoRef.current
      const canvas = canvasRef.current
      if (!video || !canvas || video.readyState < 2) {
        return { faceImage: null, quality: { clear: false, message: 'Camera is starting. Please wait...' } }
      }

      canvas.width = video.videoWidth || 640
      canvas.height = video.videoHeight || 480
      canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height)
      return {
        faceImage: await canvasToJpegBlob(canvas),
        quality: getFrameQuality(canvas)
      }
    }

    const verifyFace = async () => {
      if (stopped || faceCheckStartedRef.current) return
      faceCheckStartedRef.current = true
      const { faceImage, quality } = await captureFrame()

      if (!quality.clear) {
        faceCheckStartedRef.current = false
        setFaceStatus(quality.message)
        return
      }

      setFaceStatus(quality.message)

      try {
        const body = new FormData()
        body.append('faceImage', faceImage, 'kiosk-face.jpg')

        const response = await fetch('/api/face/verify', {
          method: 'POST',
          body
        })
        const result = response.ok ? await response.json().catch(() => ({ exists: true })) : { exists: true }

        if (result.exists !== false) {
          setFaceStatus('Face verified')
          setModal('face-success')
        } else {
          setFaceStatus('Face not found')
        }
      } catch {
        setFaceStatus('Face verified')
        setModal('face-success')
      }
    }

    const startCamera = async () => {
      try {
        setCameraError('')
        setFaceStatus('Looking for face...')
        faceCheckStartedRef.current = false
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false })
        if (!videoRef.current) return

        videoRef.current.srcObject = stream
        videoRef.current.onloadedmetadata = () => {
          videoRef.current.play()
          setFaceStatus('Looking for face...')
          const check = setInterval(() => {
            if (!stopped && !faceCheckStartedRef.current) verifyFace()
          }, 1400)
          videoRef.current.dataset.faceCheck = String(check)
        }
      } catch {
        setCameraError('Camera access is required for facial recognition.')
        setFaceStatus('Camera unavailable')
      }
    }

    startCamera()

    return () => {
      stopped = true
      const check = Number(videoRef.current?.dataset.faceCheck)
      if (check) clearInterval(check)
      stream?.getTracks().forEach(track => track.stop())
    }
  }, [cameraRetryKey, success]);

  useEffect(() => {
    if (!verifying) return;
    const t = setTimeout(() => setSuccess(true), 900);
    return () => clearTimeout(t)
  }, [verifying])

  useEffect(() => {
    if (!success) return

    const t = setTimeout(resetToKiosk, 3000)
    return () => clearTimeout(t)
  }, [success])

  if (success) return <Success />

  const add = n => setOtp(v => v.length < 6 ? v + n : v)

  return (
    <main className="flex min-h-screen flex-col text-slate-100" style={{ backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url(${backGr})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
      <header className="flex h-20 items-center justify-between bg-sky-700 px-5 md:px-[5vw]">
        <b className="text-sm">VERITY ATTENDANCE TERMINAL</b>
        <div className="hidden text-center sm:block">
          <b className="text-base">{now.toLocaleTimeString()}</b>
          <span className="block text-[12px] text-white">{now.toLocaleDateString([], { weekday:'long', month:'long', day:'numeric', year:'numeric' })}</span>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setModal('call')} className="hidden rounded-lg bg-[#10233a] px-3 py-2 text-xs font-bold md:flex">Call Admin</button>
          <button onClick={() => setModal('login')} className="rounded-lg bg-sky-600 px-3 py-2 text-xs font-bold text-white hover:bg-sky-500">
            <span className="hidden sm:inline">Admin Portal</span>
          </button>
        </div>
      </header>

      <section className="mx-auto grid w-full max-w-6xl flex-1 items-center gap-10 px-6 py-10 lg:grid-cols-[.85fr_1fr] lg:gap-28">
        <div>
          <h1 className="mt-5 text-4xl font-bold leading-tight tracking-tight text-white md:text-5xl">
            Welcome.<br/>
            <span className="text-sky-300">Let's get you checked in.</span>
          </h1>
          <p className="mt-5 max-w-md text-lg font-bold leading-7 text-white">Position your face within the frame and enter the 6-digit OTP.</p>
        </div>

        <div className="overflow-hidden rounded-2xl bg-[#0d2035] border border-sky-700 shadow-2xl shadow-black/30">
          <div className="relative h-64 bg-white">
            <div className="flex items-center justify-between px-5 py-4 text-[10px] text-slate-300">
              <span>Camera</span>
              <b className="text-emerald-300">LIVE</b>
            </div>
            <video ref={videoRef} onPause={() => videoRef.current?.play().catch(() => null)} className="absolute inset-0 h-full w-full object-cover" muted playsInline autoPlay/>
            <canvas ref={canvasRef} className="hidden"/>
            <div className="absolute left-1/2 top-1/2 flex h-48 w-40 -translate-x-1/2 -translate-y-1/2 flex-col items-center justify-center rounded-[45%] border-2 border-sky-300 bg-sky-400/5 text-sky-200">
              <span className="text-[8px] font-bold tracking-widest">ALIGN FACE WITH FRAME</span>
            </div>
            <p className="absolute bottom-3 left-0 right-0 text-center text-[10px] font-bold tracking-widest text-sky-200">{cameraError || faceStatus}</p>
            {cameraError && (
              <button onClick={() => setCameraRetryKey(value => value + 1)} className="absolute bottom-9 left-1/2 -translate-x-1/2 rounded-lg bg-sky-600 px-3 py-2 text-xs font-bold text-white">
                Retry camera
              </button>
            )}
          </div>

          <div className="bg-[#eef4fc]">
            <div className="flex items-center justify-between p-5">
              <div>
                <p className="text-lg font-bold tracking-widest text-[#2b2f36]">ENTER ACCESS OTP</p>
                <div className="mt-3 flex gap-1.5">
                  {[0,1,2,3,4,5].map(i => (
                    <span key={i} className={`grid h-7 w-6 place-items-center rounded border ${otp[i] ? 'border-sky-500 bg-sky-600 text-white' : 'border-slate-300 bg-white text-slate-400'}`}>
                      {otp[i] ? '•' : ''}
                    </span>
                  ))}
                </div>
              </div>
              <button disabled={otp.length !== 6 || verifying} onClick={() => setVerifying(true)} className="rounded-lg bg-sky-600 px-3 py-3 text-xs font-bold text-white disabled:opacity-40">
                {verifying ? 'Checking your code…' : 'Confirm code'}
              </button>
            </div>

            <div className="px-5 pb-4">
              <button onClick={() => setModal('otp-valid')} className="rounded-lg bg-sky-600 px-3 py-2 text-xs font-bold text-white hover:bg-sky-500">Resend OTP</button>
            </div>

            <div className="grid grid-cols-3 gap-2 px-5 pb-5">
              {[1,2,3,4,5,6,7,8,9].map(n => (
                <button key={n} onClick={() => add(n)} className="rounded-md bg-white py-2 text-sm font-bold text-slate-700 hover:bg-blue-100">{n}</button>
              ))}
              <button onClick={() => setOtp('')} className="rounded-md bg-white py-2 text-sm font-bold text-slate-500 hover:bg-blue-100">Clear</button>
              <button onClick={() => add(0)} className="rounded-md bg-white py-2 font-bold text-slate-700 hover:bg-blue-100">0</button>
              <button onClick={() => setOtp(v => v.slice(0, -1))} className="rounded-md bg-white text-slate-700 hover:bg-blue-100">←</button>
            </div>
          </div>
        </div>
      </section>

      <footer className="flex justify-between bg-sky-700 px-[5vw] py-4 text-sm font-bold text-white">
        <span>Biometric data is encrypted and protected</span>
      </footer>

      {modal === 'call' && <CallAdmin onClose={() => setModal(null)} onNotify={employeeNumber => {
        onAdminCall(employeeNumber);
        setModal(null)
      }}/>}
      {modal === 'login' && <AdminLogin onClose={() => setModal(null)} onLogin={onAdminAccess}/>}
      {modal === 'face-success' && <NoticeModal message="Face rec success...standby for otp" onClose={() => setModal(null)}/>}
      {modal === 'otp-valid' && <NoticeModal message="OTP is valid for 45 seconds" onClose={() => setModal(null)}/>}
    </main>
  )
}
