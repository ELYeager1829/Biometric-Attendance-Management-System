import { useState } from "react";
import { Routes, Route, Navigate, useNavigate } from "react-router-dom";


import Dashboard from "../features/dashboard/pages/Dashboard";
import HrDashboard from "../features/hr/pages/HrDashboard";
import KioskPage from "../features/kiosk/pages/KioskPage";
import OnboardPage from "../features/onboarding/pages/OnboardPage";

import { initialEmployees } from "../features/dashboard/data/employees";

function AppRoutes() {
  const navigate = useNavigate();

  const [employees, setEmployees] = useState(initialEmployees);
  const [pendingAdminRequest, setPendingAdminRequest] = useState(null);

  return (
    <Routes>


      {/* Default page */}
      <Route
        path="/"
        element={<Navigate to="/kiosk" replace />}
      />
      {/* Existing dashboard */}
      <Route
        path="/dashboard"
        element={
          <Dashboard
            employees={employees}
            pendingAdminRequest={pendingAdminRequest}

            onClearAdminRequest={() =>
              setPendingAdminRequest(null)
            }

            onEmployeesChange={setEmployees}

            onEditEmployee={(employee) =>
              navigate("/onboard", {
                state: {
                  mode: "edit",
                  employee
                }
              })
            }

            onLogout={() => {
              localStorage.removeItem("token");
              localStorage.removeItem("role");
              navigate("/");
            }}

            onOnboard={() =>
              navigate("/onboard", {
                state: {
                  mode: "create"
                }
              })
            }
          />
        }
      />

      {/* Admin */}
      <Route
        path="/admin"
        element={
          <Dashboard
            employees={employees}
            pendingAdminRequest={pendingAdminRequest}

            onClearAdminRequest={() =>
              setPendingAdminRequest(null)
            }

            onEmployeesChange={setEmployees}

            onEditEmployee={(employee) =>
              navigate("/onboard", {
                state: {
                  mode: "edit",
                  employee
                }
              })
            }

            onLogout={() => {
              localStorage.removeItem("token");
              localStorage.removeItem("role");
              navigate("/");
            }}

            onOnboard={() =>
              navigate("/onboard", {
                state: {
                  mode: "create"
                }
              })
            }
          />
        }
      />

      {/* Employee onboarding + facial capture */}
      <Route
        path="/onboard"
        element={
          <OnboardPage
            mode="create"
            onBack={() => navigate("/dashboard")}
          />
        }
      />

      {/* HR */}
      <Route
        path="/hr"
        element={
          <HrDashboard
            onLogout={() => {
              localStorage.removeItem("token");
              localStorage.removeItem("role");
              navigate("/");
            }}
          />
        }
      />

      {/* Kiosk */}
      <Route
        path="/kiosk"
        element={
          <KioskPage
            employees={employees}

            onAdminAccess={(role) => {
              if (role === "hr") {
                navigate("/hr");
              } else {
                navigate("/admin");
              }
            }}

            onAdminCall={(employeeNumber) => {
              setPendingAdminRequest({
                employeeNumber
              });

              console.log(
                "Admin request for:",
                employeeNumber
              );
            }}
          />
        }
      />

    </Routes>
  );
}

export default AppRoutes;